import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {
    private int gridSize;
    private int trials;
    private double[] trialsResult;
    private Percolation perc;

    public PercolationStats(int n, int trials) {
        if (n <= 0) {
            throw new IllegalArgumentException("Number must be positive integer");
        }

        gridSize = n;
        this.trials = trials;
        trialsResult = new double[trials];

        StdOut.println(gridSize + "|" + trials);

        runExperiment();
    }

    private void runExperiment() {
        int row;
        int col;
        int openSite;
        double result;
        for (int i = 0; i < trials; i++) {
            perc = new Percolation(gridSize);
            while (!perc.percolates()) {
                row = StdRandom.uniformInt(1, gridSize + 1);
                col = StdRandom.uniformInt(1, gridSize + 1);
                // StdOut.println(row + "|" + col);
                perc.open(row, col);
            }
            openSite = perc.numberOfOpenSites();
            result = (double) openSite / gridSize * gridSize;
            trialsResult[i] = result;
        }
    }

    public double mean() {
        return StdStats.mean(trialsResult);
    }

    public double stddev() {
        return StdStats.stddev(trialsResult);
    }

    public double confidenceLo() {
        return mean() - ((1.96 * stddev()) / Math.sqrt(trials));
    }

    public double confidenceHi() {
        return mean() + ((1.96 * stddev()) / Math.sqrt(trials));
    }

    public static void main(String[] args) {
        int n = 200;
        int trials = 100;
        if (args.length > 1) {
            n = Integer.parseInt(args[0]);
            trials = Integer.parseInt(args[1]);
        }

        PercolationStats percStats = new PercolationStats(n, trials);
        StdOut.printf("mean                     = %.7f%n", percStats.mean());
        StdOut.printf("stddev                   = %.17f%n", percStats.stddev());
        StdOut.printf("95%% confidence interval  = [%.15f, %.15f]%n",
                percStats.confidenceLo(), percStats.confidenceHi());
    }
}
