import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private int gridSize;
    private int gridSquare;
    private int virtualTop;
    private int virtualBot;
    private int openSite;
    private boolean[][] grid;
    private WeightedQuickUnionUF wquGrid;

    public Percolation(int n) {
        if (n <= 0)
            throw new IllegalArgumentException("Argument must be positive number");

        gridSize = n;
        gridSquare = n * n;
        virtualTop = gridSquare;
        virtualBot = gridSquare + 1;
        openSite = 0;
        grid = new boolean[gridSize][gridSize];
        wquGrid = new WeightedQuickUnionUF(gridSquare + 2);
    }

    public void open(int row, int col) {
        validate(row, col);

        int shiftRow = row - 1;
        int shiftCol = col - 1;
        int site = getSite(row, col);

        // Check whether the site is alerady open
        if (isOpen(row, col)) {
            return;
        }

        // Open the site
        grid[shiftRow][shiftCol] = true;
        openSite++;

        // Check top row and union to virtual top
        if (row == 1) {
            wquGrid.union(virtualTop, site);
        }

        // Check bottom row and union to virtual bottom
        if (row == gridSize) {
            wquGrid.union(virtualBot, site);
        }

        // Check left and union
        if (isOnGrid(row, col - 1) && isOpen(row, col - 1)) {
            wquGrid.union(site, getSite(row, col - 1));
        }

        // Check right and union
        if (isOnGrid(row, col + 1) && isOpen(row, col + 1)) {
            wquGrid.union(site, getSite(row, col + 1));
        }

        // Check up and union
        if (isOnGrid(row - 1, col) && isOpen(row - 1, col)) {
            wquGrid.union(site, getSite(row - 1, col));
        }

        // Check down and union
        if (isOnGrid(row + 1, col) && isOpen(row + 1, col)) {
            wquGrid.union(site, getSite(row + 1, col));
        }
    }

    public boolean isOpen(int row, int col) {
        validate(row, col);
        return grid[row - 1][col - 1];
    }

    public boolean isFull(int row, int col) {
        validate(row, col);
        return wquGrid.find(virtualTop) == wquGrid.find(getSite(row, col));
    }

    public int numberOfOpenSites() {
        return openSite;
    }

    public boolean percolates() {
        return wquGrid.find(virtualTop) == wquGrid.find(virtualBot);
    }

    private void validate(int row, int col) {
        if (!isOnGrid(row, col))
            throw new IllegalArgumentException("Number out of bonds");
    }

    private boolean isOnGrid(int row, int col) {
        int shiftRow = row - 1;
        int shiftCol = col - 1;
        return (shiftRow >= 0 && shiftRow < gridSize && shiftCol >= 0 && shiftCol < gridSize);
    }

    private int getSite(int row, int col) {
        validate(row, col);
        return (gridSize * (row - 1) + col) - 1;
    }

    public static void main(String[] args) {
        int n = StdIn.readInt();
        int row = 0;
        int col = 0;

        Percolation perc = new Percolation(n);
        while (!StdIn.isEmpty()) {
            row = StdIn.readInt();
            col = StdIn.readInt();
            perc.open(row, col);
        }

        StdOut.println(perc.percolates());
        StdOut.println(perc.numberOfOpenSites());
    }
}
